var express = require('express');
var app = express();
var fs = require("fs");
var bodyParser = require('body-parser');
var cors = require('cors');

var multer = require('multer'); // v1.0.5
var upload = multer(); // for parsing multipart/form-data

// https://www.w3schools.com/nodejs/nodejs_mysql.asp
var mysql = require('mysql');

const models = require('/home/nhti/Node/pubs/models.js');
const { json } = require('body-parser');
const { publicDecrypt } = require('crypto');

app.use(cors({
	origin: '*',
	methods: ['GET', 'POST', 'PUT', 'DELETE'],
	allowedHeaders: ['Content']
}))

var con = mysql.createConnection({
  host: "localhost",
  user: "student",
  password: "nhti",
  database: "pubs"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected to pubs!");
});

// at the API layer, information would be spun into javascript objects
// and passed to the Service layer. Here, values are passed directly for simplicity.

app.get('/rest/jobs', function (req, res) {

		console.log("Req all jobs"); 
		ServGetJobs(res);
	
}) // end get jobs

app.get('/rest/jobs/:job_id', function (req, res) {

	if(req.params.job_id)
	{
		ServGetJob(req.params.job_id,res);
	}

}) // end get jobs

app.get('/rest/pubs', function (req, res) {
	console.log("Getting all Publishers");
	ServGetPubs(res);
}) // end get publishers

app.get('/rest/employees', function (req, res){
	console.log("Getting all Employees");
	ServGetEmployees(res);
}) // end get employees

app.get('/rest/employees/:emp_id', function(req, res){
	if(req.params.emp_id){
		console.log("Req employee with ID " + req.params.emp_id);

		//var sql = "SELECT * FROM employee WHERE emp_id = ?";

		//con.query(sql, [req.params.emp_id], function(err, result, fields){
		//	if(err) throw err;
		//	res.json(result);
		//});

		ServiceGetEmployee(req.params.emp_id, res);
	}
	else{
		console.log("BAD GET employee");
	}
})

app.get("/rest/pubs/:pub_id", function(req, res){
	if(req.params.pub_id){
		console.log("Req employee with ID " + req.params.emp_id);		

		ServGetPub(req.params.pub_id, res);
	}
})

// https://github.com/expressjs/body-parser
var jsonParser = bodyParser.json()

app.post('/rest/jobs', jsonParser, function (req, res, next) {

	console.log(req.body); 

	

	if(!req.body.job_desc || !req.body.min_lvl || !req.body.max_lvl) 
	{
		console.log("BAD POST jobs"); 
		// https://www.bennadel.com/blog/2434-http-status-codes-for-invalid-data-400-vs-422.htm
		res.status(422).end();
	}
	else // params OK
	{
		console.log("POST jobs"); 
		ServPostJob(req, res);
	}

}) // end post job

app.post('/rest/employees', jsonParser, function(req, res, next){
	console.log(req.body);

	if(!req.body.emp_id || !req.body.job_lvl || !req.body.pub_id
		|| !req.body.fname || !req.body.lname || !req.body.hire_date
		|| !req.body.job_id) 
	{
		console.log("BAD POST employees"); 
		// https://www.bennadel.com/blog/2434-http-status-codes-for-invalid-data-400-vs-422.htm
		res.status(422).end();
	}
	else {
		console.log("POST employees");
		ServPostEmp(req, res);
	}
		
})

app.put('/rest/employees', jsonParser, function(req, res, next){
	console.log(req.body);

	if(!req.body.emp_id || !req.body.job_lvl || !req.body.job_id) 
	{
		console.log("BAD PUT employees: need emp id, job id, and job level"); 
		// https://www.bennadel.com/blog/2434-http-status-codes-for-invalid-data-400-vs-422.htm
		res.status(422).end();
	}
	else
	{
		console.log("PUT employee " + req.body.emp_id);
		ServPutEmp(req, res);
	}
})

app.delete('/rest/employees/:emp_id', function(req, res, next){
	if(!req.params.emp_id){
		console.log("BAD DELETE employee " + req.params.emp_id);
		res.status(422).end();
	}
	else{
		console.log("deleting employee " + req.params.emp_id);
		ServDeleteEmp(req.params.emp_id, res);
	}
})

var server = app.listen(80, function () {
   var host = server.address().address
   var port = server.address().port
   console.log("Example app listening at http://%s:%s", host, port)
})


// Service Layer
// data manipulation, external API calls, and error checking go here

function ServiceGetEmployee(emp_id, res){

	// do data manipulation, error checking, etc. here

	IntegrationGetEmployee(emp_id, res);
}

function ServGetEmployees(res){
	IntegGetEmployees(res);
}

function ServGetJobs(res){
	IntegGetJobs(res);
}

function ServGetJob(job_id, res){
	IntegGetJob(job_id, res);
}

function ServGetPubs(res){
	IntegGetPubs(res);
}

function ServGetPub(pub_id, res){
	IntegGetPub(pub_id, res);
}

function ServPostJob(req, res){
	IntegPostJob(req, res);
}

function ServPostEmp(req, res){
	IntegPostEmp(req, res);
}

function ServPutEmp(req, res){
	IntegPutEmp(req, res);
}

function ServDeleteEmp(emp_id, res){
	IntegDeleteEmp(emp_id, res);
}

// Integration Layer
// Here is where the repositories and other database-interface code is executed

function IntegrationGetEmployee(emp_id, res){
	console.log("integ layer get employee ID " + emp_id);

	//console.log(output);
	var sql = "SELECT * FROM employee WHERE emp_id = ?";
	
	con.query(sql,[emp_id], function(err, result){
		if(err) throw err;
		res.send(result);
	});
}

function IntegGetEmployees(res){
	con.query("SELECT * FROM employee", function(err, result, fields){
		if(err) throw err;
		res.json(result);
	});
}

function IntegGetJobs(res){
	con.query("SELECT * FROM jobs", function (err, result, fields) {
		if (err) throw err;
		res.json( result );
	});
}

function IntegGetJob(job_id, res){
	var sql = "SELECT * FROM jobs WHERE job_id = ?"; 
		con.query(sql, [job_id] , function (err, result, fields) {
    			if (err) throw err;
				console.log(result);
    			res.json( result );
		});
}

function IntegGetPubs(res){
	con.query("SELECT * FROM publishers", function(err, result, fields) {
		if(err) throw err;
		res.json(result);
	});
}

function IntegGetPub(pub_id, res){
	var sql = "SELECT * FROM publishers WHERE pub_id = ?";

		con.query(sql, [pub_id], function(err, result, fields){
			if(err) throw err;
			res.json(result);
		});
}

function IntegPostJob(req, res){
	var sql = "INSERT INTO jobs (job_desc, min_lvl, max_lvl) ";
		sql += "VALUES (?, ?, ?)"; 

		con.query(sql, [req.body.job_desc, 
				req.body.min_lvl, 
				req.body.max_lvl] , function (err, result) {
    			if (err) throw err;
    			res.send( result );
		});
}

function IntegPostEmp(req, res){
	var sql = "INSERT INTO employee (emp_id, fname, minit, lname, job_id, " +
			"job_lvl, pub_id, hire_date)";
			sql += "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		con.query(sql, [req.body.emp_id,
			req.body.fname,
			req.body.minit,
			req.body.lname,
			req.body.job_id,
			req.body.job_lvl,
			req.body.pub_id,
			req.body.hire_date],
			function(err, result){
				if(err) throw err;
				res.send(result);
			});
}

function IntegPutEmp(req, res){
	var sql = "UPDATE employee SET job_lvl = ?, job_id = ? WHERE emp_id = ?";

		con.query(sql, [req.body.job_lvl, req.body.job_id, req.body.emp_id],
			function(err, result){
				if(err) throw err;
				res.send(result);
			});
}

function IntegDeleteEmp(emp_id, res){
	var sql = "DELETE FROM employee WHERE emp_id = ?";

		con.query(sql, [emp_id], function(err, result){
			if(err) throw err;
			res.send(result);
		});
}
