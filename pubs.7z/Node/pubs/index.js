var express = require('express');
var app = express();
var fs = require("fs");
var bodyParser = require('body-parser');

var multer = require('multer'); // v1.0.5
var upload = multer(); // for parsing multipart/form-data

// https://www.w3schools.com/nodejs/nodejs_mysql.asp
var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "student",
  password: "nhti",
  database: "pubs"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected to pubs!");
});

app.get('/rest/jobs', function (req, res) {

		console.log("Req all jobs"); 
		con.query("SELECT * FROM jobs", function (err, result, fields) {
    			if (err) throw err;
    			res.json( result );
		});
	
}) // end get jobs

app.get('/rest/jobs/:job_id', function (req, res) {

	if(req.params.job_id)
	{
		console.log("Req job: " + req.params.job_id); 
		var sql = "SELECT * FROM jobs WHERE job_id = ?"; 
		con.query(sql, [req.params.job_id] , function (err, result, fields) {
    			if (err) throw err;
    			res.json( result );
		});
	}

}) // end get jobs

app.get('/rest/pubs', function (req, res) {
	console.log("Getting all Publishers");
	con.query("SELECT * FROM publishers", function(err, result, fields) {
		if(err) throw err;
		res.json(result);
	});
}) // end get publishers

app.get('/rest/employees', function (req, res){
	console.log("Getting all Employees");
	con.query("SELECT * FROM employee", function(err, result, fields){
		if(err) throw err;
		res.json(result);
	});
}) // end get employees

app.get('/rest/employees/:emp_id', function(req, res){
	if(req.params.emp_id){
		console.log("Req employee with ID " + req.params.emp_id);
		var sql = "SELECT * FROM employee WHERE emp_id = ?";
		con.query(sql, [req.params.emp_id], function(err, result, fields){
			if(err) throw err;
			res.json(result);
		})
	}
})

// https://github.com/expressjs/body-parser
var jsonParser = bodyParser.json()

app.post('/rest/jobs', jsonParser, function (req, res, next) {

	console.log(req.body); 

	if(!req.body.job_desc || !req.body.min_lvl || !req.body.max_lvl) 
	{
		console.log("BAD POST jobs"); 
		// https://www.bennadel.com/blog/2434-http-status-codes-for-invalid-data-400-vs-422.htm
		res.status(422).end();
	}
	else // params OK
	{
		console.log("POST jobs"); 
		var sql = "INSERT INTO jobs (job_desc, min_lvl, max_lvl) ";
		sql += "VALUES (?, ?, ?)"; 

		con.query(sql, [req.body.job_desc, 
				req.body.min_lvl, 
				req.body.max_lvl] , function (err, result) {
    			if (err) throw err;
    			res.send( result );
		});
	}

}) // end post job

app.post('/rest/employees', jsonParser, function(req, res, next){
	console.log(req.body);

	if(!req.body.emp_id || !req.body.job_lvl || !req.body.pub_id
		|| !req.body.fname || !req.body.lname || !req.body.hire_date
		|| !req.body.job_id) 
	{
		console.log("BAD POST employees"); 
		// https://www.bennadel.com/blog/2434-http-status-codes-for-invalid-data-400-vs-422.htm
		res.status(422).end();
	}
	else {
		console.log("POST employees");
		var sql = "INSERT INTO employee (emp_id, fname, minit, lname, job_id, " +
			"job_lvl, pub_id, hire_date)";
			sql += "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		con.query(sql, [req.body.emp_id,
			req.body.fname,
			req.body.minit,
			req.body.lname,
			req.body.job_id,
			req.body.job_lvl,
			req.body.pub_id,
			req.body.hire_date],
			function(err, result){
				if(err) throw err;
				res.send(result);
			});
	}
		
})

app.put('/rest/employees', jsonParser, function(req, res, next){
	console.log(req.body);

	if(!req.body.emp_id || !req.body.job_lvl || !req.body.job_id) 
	{
		console.log("BAD PUT employees: need emp id, job id, and job level"); 
		// https://www.bennadel.com/blog/2434-http-status-codes-for-invalid-data-400-vs-422.htm
		res.status(422).end();
	}
	else
	{
		console.log("PUT employee " + req.body.emp_id);
		var sql = "UPDATE employee SET job_lvl = ?, job_id = ? WHERE emp_id = ?";

		con.query(sql, [req.body.job_lvl, req.body.job_id, req.body.emp_id],
			function(err, result){
				if(err) throw err;
				res.send(result);
			});
	}
})

var server = app.listen(80, function () {
   var host = server.address().address
   var port = server.address().port
   console.log("Example app listening at http://%s:%s", host, port)
})
