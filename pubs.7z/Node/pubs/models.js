class job
{
    constructor(id,desc,min,max){
        this.job_id = id;
        this.job_desc = desc;
        this.min_lvl = min;
        this.max_lvl = max;
    }
    job_id;
    job_desc;
    min_lvl;
    max_lvl;
}

class employee
{
    constructor(id,fn,mn,ln,job,level,pub,hire){
        this.emp_id = id;
        this.fn = fn;
        this.minit = mn;
        this.lname = ln;
        this.job_id = job;
        this.job_lvl = level;
        this.pub_id = pub;
        this.hire_date = hire;
    }
    emp_id;
    fname;
    minit;
    lname;
    job_id;
    job_lvl;
    pub_id;
    hire_date;
}

class publisher
{
    constructor(pub_id, pub_name, city, state, country){
        this.pub_id = pub_id;
        this.pub_name = pub_name;
        this.city = city;
        this.state = state;
        this.country = country;
    }
}

module.exports = {job, employee, publisher};