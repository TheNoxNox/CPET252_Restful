var express = require('express');
var app = express();
var fs = require("fs");
var bodyParser = require('body-parser');

var multer = require('multer'); // v1.0.5
var upload = multer(); // for parsing multipart/form-data

// https://www.w3schools.com/nodejs/nodejs_mysql.asp
var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "student",
  password: "nhti",
  database: "pubs"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected to pubs!");
});

app.get('/jobs', function (req, res) {

		console.log("Req all jobs"); 
		con.query("SELECT * FROM jobs", function (err, result, fields) {
    			if (err) throw err;
    			res.json( result );
		});
	
}) // end get jobs

app.get('/jobs/:job_id', function (req, res) {

	if(req.params.job_id)
	{
		console.log("Req job: " + req.params.job_id); 
		var sql = "SELECT * FROM jobs WHERE job_id = ?"; 
		con.query(sql, [req.params.job_id] , function (err, result, fields) {
    			if (err) throw err;
    			res.json( result );
		});
	}

}) // end get jobs

// https://github.com/expressjs/body-parser
var jsonParser = bodyParser.json()

app.post('/jobs', jsonParser, function (req, res, next) {

	console.log(req.body); 

	if(!req.body.job_desc || !req.body.min_lvl || !req.body.min_lvl) 
	{
		console.log("BAD POST jobs"); 
		// https://www.bennadel.com/blog/2434-http-status-codes-for-invalid-data-400-vs-422.htm
		res.status(422).end();
	}
	else // params OK
	{
		console.log("POST jobs"); 
		var sql = "INSERT INTO jobs (job_desc, min_lvl, max_lvl) ";
		sql += "VALUES (?, ?, ?)"; 

		con.query(sql, [req.body.job_desc, 
				req.body.min_lvl, 
				req.body.max_lvl] , function (err, result) {
    			if (err) throw err;
    			res.send( result );
		});
	}

}) // end post job

var server = app.listen(80, function () {
   var host = server.address().address
   var port = server.address().port
   console.log("Example app listening at http://%s:%s", host, port)
})
