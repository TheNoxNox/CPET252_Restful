

let mysql = require('mysql');

let connection = mysql.createConnection({
    host:'localhost',
    user:'student',
    password:'nhti',
    database: 'pubs'
}); 

connection.connect(function(err){

    if(err){
        return console.error("failed to connect to database: " + err.message); 
    }

    console.log("connected to pubs okay"); 

}); 

var sql = "SELECT * from authors"; 

connection.query(sql, 
    function(err, result, fields){
        if(err) {
            console.error("SQL Failed" + err.message); 
        }else{
            // should be JSON array of authors
            console.log(result); 
        }

    }
); 


connection.end(function(err){
    if(err)
    {
        return console.error("Failed to close connection: " + err.message)
        
    }

    console.log("Connection closed okay"); 
}); 

// destroy ends callbacks, so you do not see messages in connect and end 
//connection.destroy(); // will not see console messages 

