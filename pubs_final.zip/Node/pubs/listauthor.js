

let mysql = require('mysql');

let connection = mysql.createConnection({
    host:'localhost',
    user:'student',
    password:'nhti',
    database: 'pubs'
}); 

connection.connect(function(err){

    if(err){
        return console.error("failed to connect to database: " + err.message); 
    }

    console.log("connected to pubs okay"); 

}); 

var sql = "SELECT * from authors where au_id = ?"; 

connection.query(sql, ['998-72-3567'],
    function(err, result, fields){
        if(err) {
            console.error("SQL Failed" + err.message); 
        }else{
            // single author in array
            console.log(result); 
        }

    }
); 


connection.end(function(err){
    if(err)
    {
        return console.error("Failed to close connection: " + err.message)
        
    }

    console.log("Connection closed okay"); 
}); 

// destroy ends callbacks, so you do not see messages in connect and end 
//connection.destroy(); // will not see console messages 

